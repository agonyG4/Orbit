#include <QCoreApplication>
#include <QFileInfo>
#include <QPointer>
#include <QSignalSpy>
#include <QStandardPaths>
#include <QTemporaryDir>
#include <QTimer>
#include <QTimeZone>
#include <QtTest>

#include "backend/backend_transport.h"
#include "backend/backend_types.h"
#include "backend/fake_backend_client.h"
#include "backend/one_shot_cli_transport.h"
#include "backend/rust_backend_client.h"

using namespace Astrea::Explorer::Native::Backend;

class InMemoryTransport final : public BackendTransport
{
    Q_OBJECT

public:
    struct StartedRequest
    {
        BackendRequestId id {};
        QStringList arguments;
    };

    BackendRequestId start(const QStringList &arguments) override
    {
        const BackendRequestId id = allocateRequestId();
        startedRequests.append({id, arguments});
        return id;
    }

    void cancel(BackendRequestId requestId) override
    {
        cancelledRequests.append(requestId);
    }

    void succeed(BackendRequestId requestId, const QByteArray &payload)
    {
        emitCompleted(requestId, payload);
    }

    void fail(BackendRequestId requestId, const QString &code, const QString &message)
    {
        BackendTransportError error;
        error.requestId = requestId;
        error.code = code;
        error.message = message;
        emitFailed(requestId, error);
    }

    QVector<StartedRequest> startedRequests;
    QVector<BackendRequestId> cancelledRequests;
};

class SynchronousTransport final : public BackendTransport
{
    Q_OBJECT

public:
    BackendRequestId start(const QStringList &) override
    {
        const BackendRequestId requestId = allocateRequestId();
        emitCompleted(requestId, QByteArrayLiteral("[]"));
        return requestId;
    }

    void cancel(BackendRequestId requestId) override
    {
        cancelledRequests.append(requestId);
    }

    QVector<BackendRequestId> cancelledRequests;
};

class BackendClientTest final : public QObject
{
    Q_OBJECT

private slots:
    void initTestCase();
    void decodesRoleCompatibleListPayload();
    void rejectsMalformedJsonPayload();
    void forwardsLegacyCliArgumentsForListAndSearch();
    void decodesDevicesAndForwardsDeviceOperations();
    void decodesFileOperationProgressAndResult();
    void acceptsSynchronousTransportCompletion();
    void ignoresDuplicateTerminalEvents();
    void forwardsTransportFailuresExactlyOnce();
    void fakeBackendClientEmitsTypedSignalsWithoutProcessDependencies();
    void oneShotTransportMapsNonZeroExitToFailure();
    void oneShotTransportCancelsExactlyOnce();
    void oneShotTransportCancellationIsAsynchronous();
    void oneShotTransportKillsAfterTerminateGraceExpires();
    void oneShotTransportIgnoresLateFinishedAfterCancellation();
    void oneShotTransportDestructionReleasesActiveProcess();
    void oneShotTransportTimesOutExactlyOnce();
    void oneShotTransportCapsOutput();
};

void BackendClientTest::initTestCase()
{
    qRegisterMetaType<BackendError>();
    qRegisterMetaType<QVector<DirectoryEntry>>();
}

void BackendClientTest::decodesRoleCompatibleListPayload()
{
    InMemoryTransport transport;
    RustBackendClient client(&transport);

    QSignalSpy readySpy(&client, &IRustBackendClient::listReady);
    QSignalSpy failedSpy(&client, &IRustBackendClient::failed);

    ListRequest request;
    request.path = QStringLiteral("/tmp/example");
    request.showHidden = true;
    request.sortField = QStringLiteral("date");
    request.sortAscending = false;
    request.foldersFirst = true;
    request.previews = true;

    const BackendRequestId requestId = client.list(request);
    QCOMPARE(requestId, BackendRequestId(1));
    QCOMPARE(transport.startedRequests.size(), 1);

    transport.succeed(
        requestId,
        QByteArrayLiteral(
            "[{\"fileName\":\"photo #1.png\",\"filePath\":\"/tmp/example/photo #1.png\","
            "\"fileUrl\":\"file:///tmp/example/photo%20%231.png\",\"fileIsDir\":false,"
            "\"fileExecutable\":false,\"fileHidden\":false,\"fileSize\":42,"
            "\"fileModified\":1723265945000,\"fileKind\":\"PNG\","
            "\"filePreviewUrl\":\"file:///tmp/cache/photo.png\",\"fileRemote\":false,"
            "\"fileMetadataLimited\":false,\"fileFilesystem\":\"ext4\"}]"));

    QTRY_COMPARE(readySpy.count(), 1);
    QCOMPARE(failedSpy.count(), 0);

    const QList<QVariant> signalArguments = readySpy.takeFirst();
    QCOMPARE(signalArguments.at(0).value<BackendRequestId>(), requestId);

    const QVector<DirectoryEntry> entries =
        signalArguments.at(1).value<QVector<DirectoryEntry>>();
    QCOMPARE(entries.size(), 1);
    QCOMPARE(entries.constFirst().fileName, QStringLiteral("photo #1.png"));
    QCOMPARE(entries.constFirst().filePath, QStringLiteral("/tmp/example/photo #1.png"));
    QCOMPARE(entries.constFirst().fileUrl, QUrl(QStringLiteral("file:///tmp/example/photo%20%231.png")));
    QCOMPARE(entries.constFirst().fileIsDir, false);
    QCOMPARE(entries.constFirst().fileExecutable, false);
    QCOMPARE(entries.constFirst().fileHidden, false);
    QCOMPARE(entries.constFirst().fileSize, 42);
    QCOMPARE(
        entries.constFirst().fileModified,
        QDateTime::fromMSecsSinceEpoch(1723265945000, QTimeZone::UTC));
    QCOMPARE(entries.constFirst().fileKind, QStringLiteral("PNG"));
    QCOMPARE(entries.constFirst().filePreviewUrl, QUrl(QStringLiteral("file:///tmp/cache/photo.png")));
    QCOMPARE(entries.constFirst().fileRemote, false);
    QCOMPARE(entries.constFirst().fileMetadataLimited, false);
    QCOMPARE(entries.constFirst().fileFilesystem, QStringLiteral("ext4"));
}

void BackendClientTest::rejectsMalformedJsonPayload()
{
    InMemoryTransport transport;
    RustBackendClient client(&transport);

    QSignalSpy failedSpy(&client, &IRustBackendClient::failed);

    ListRequest request;
    request.path = QStringLiteral("/tmp/example");
    request.sortField = QStringLiteral("name");
    request.sortAscending = true;
    request.foldersFirst = true;
    request.previews = true;

    const BackendRequestId requestId = client.list(request);
    transport.succeed(requestId, QByteArrayLiteral("{not-json"));

    QTRY_COMPARE(failedSpy.count(), 1);
    const BackendError error = failedSpy.takeFirst().constFirst().value<BackendError>();
    QCOMPARE(error.requestId, requestId);
    QCOMPARE(error.code, QStringLiteral("decode_error"));
    QVERIFY(error.message.contains(QStringLiteral("JSON"), Qt::CaseInsensitive));
}

void BackendClientTest::forwardsLegacyCliArgumentsForListAndSearch()
{
    InMemoryTransport transport;
    RustBackendClient client(&transport);

    ListRequest listRequest;
    listRequest.path = QStringLiteral("/tmp/list path");
    listRequest.showHidden = true;
    listRequest.sortField = QStringLiteral("kind");
    listRequest.sortAscending = false;
    listRequest.foldersFirst = false;
    listRequest.previews = false;

    SearchRequest searchRequest;
    searchRequest.rootPath = QStringLiteral("/tmp/search root");
    searchRequest.query = QStringLiteral("Needle");
    searchRequest.showHidden = true;
    searchRequest.sortField = QStringLiteral("date");
    searchRequest.sortAscending = false;
    searchRequest.foldersFirst = true;

    const BackendRequestId listId = client.list(listRequest);
    const BackendRequestId searchId = client.search(searchRequest);

    QCOMPARE(listId, BackendRequestId(1));
    QCOMPARE(searchId, BackendRequestId(2));
    QCOMPARE(transport.startedRequests.size(), 2);
    QCOMPARE(
        transport.startedRequests.at(0).arguments,
        QStringList(
            {QStringLiteral("list"),
             QStringLiteral("/tmp/list path"),
             QStringLiteral("1"),
             QStringLiteral("kind"),
             QStringLiteral("0"),
             QStringLiteral("0"),
             QStringLiteral("--preview-mode"),
             QStringLiteral("none")}));
    QCOMPARE(
        transport.startedRequests.at(1).arguments,
        QStringList(
            {QStringLiteral("search"),
             QStringLiteral("/tmp/search root"),
             QStringLiteral("Needle"),
             QStringLiteral("1"),
             QStringLiteral("date"),
             QStringLiteral("0"),
             QStringLiteral("1")}));
}

void BackendClientTest::decodesDevicesAndForwardsDeviceOperations()
{
    InMemoryTransport transport;
    RustBackendClient client(&transport);

    QSignalSpy devicesSpy(&client, &IRustBackendClient::devicesReady);
    QSignalSpy operationSpy(&client, &IRustBackendClient::deviceOperationReady);

    const BackendRequestId devicesId = client.devices();
    QCOMPARE(transport.startedRequests.constLast().arguments, QStringList({QStringLiteral("devices")}));
    transport.succeed(
        devicesId,
        QByteArrayLiteral(
            "[{\"id\":\"path:/dev/sdb1\",\"devicePath\":\"/dev/sdb1\","
            "\"title\":\"USB\",\"subtitle\":\"32 GB · FAT32\","
            "\"mountPath\":\"/run/media/user/USB\",\"desiredMountPath\":\"\","
            "\"mounted\":true,\"canMount\":false,\"canUnmount\":true,"
            "\"canRemount\":false,\"removable\":true,\"icon\":\"drive-removable-media\"}]"));

    QTRY_COMPARE(devicesSpy.count(), 1);
    const QVector<DeviceEntry> devices = devicesSpy.takeFirst().at(1).value<QVector<DeviceEntry>>();
    QCOMPARE(devices.size(), 1);
    QCOMPARE(devices.constFirst().id, QStringLiteral("path:/dev/sdb1"));
    QCOMPARE(devices.constFirst().mounted, true);
    QCOMPARE(devices.constFirst().mountPath, QStringLiteral("/run/media/user/USB"));

    const BackendRequestId mountId = client.mount(QStringLiteral("/dev/sdb1"));
    QCOMPARE(transport.startedRequests.constLast().arguments,
             QStringList({QStringLiteral("mount"), QStringLiteral("/dev/sdb1")}));
    transport.succeed(
        mountId,
        QByteArrayLiteral("{\"ok\":true,\"mountPath\":\"/run/media/user/USB\",\"message\":\"mounted\"}"));
    QTRY_COMPARE(operationSpy.count(), 1);
    const DeviceOperationResult result = operationSpy.takeFirst().at(1)
                                             .value<DeviceOperationResult>();
    QCOMPARE(result.ok, true);
    QCOMPARE(result.mountPath, QStringLiteral("/run/media/user/USB"));
    QCOMPARE(result.message, QStringLiteral("mounted"));
}

void BackendClientTest::decodesFileOperationProgressAndResult()
{
    InMemoryTransport transport;
    RustBackendClient client(&transport);

    QSignalSpy progressSpy(&client, &IRustBackendClient::fileOperationProgress);
    QSignalSpy readySpy(&client, &IRustBackendClient::fileOperationReady);
    QSignalSpy failedSpy(&client, &IRustBackendClient::failed);

    FileOperationRequest request;
    request.mode = QStringLiteral("copy");
    request.destination = QStringLiteral("/tmp/destination");
    request.conflictPolicy = QStringLiteral("keep-both");
    request.progressMode = QStringLiteral("items");
    request.sources = {QStringLiteral("/tmp/source.txt")};

    const BackendRequestId requestId = client.fileOperation(request);
    QCOMPARE(
        transport.startedRequests.constLast().arguments,
        QStringList({QStringLiteral("file-op"), QStringLiteral("--json-events"),
                      QStringLiteral("copy"), QStringLiteral("/tmp/destination"),
                      QStringLiteral("keep-both"), QStringLiteral("--progress"),
                      QStringLiteral("items"), QStringLiteral("/tmp/source.txt")}));

    transport.succeed(
        requestId,
        QByteArrayLiteral(
            "{\"event\":\"start\",\"mode\":\"copy\",\"destination\":\"/tmp/destination\",\"total\":1}\n"
            "{\"event\":\"progress\",\"mode\":\"copy\",\"done\":1,\"total\":1,\"percent\":100,\"path\":\"/tmp/source.txt\",\"name\":\"source.txt\"}\n"
            "{\"event\":\"done\",\"mode\":\"copy\",\"destination\":\"/tmp/destination\",\"done\":1,\"total\":1,\"percent\":100}\n"));

    QTRY_COMPARE(progressSpy.count(), 1);
    QTRY_COMPARE(readySpy.count(), 1);
    QCOMPARE(failedSpy.count(), 0);
    const FileOperationProgress progress =
        progressSpy.takeFirst().at(1).value<FileOperationProgress>();
    QCOMPARE(progress.requestId, requestId);
    QCOMPARE(progress.fileName, QStringLiteral("source.txt"));
    QCOMPARE(progress.percent, 100);
    const FileOperationResult result =
        readySpy.takeFirst().at(1).value<FileOperationResult>();
    QCOMPARE(result.requestId, requestId);
    QCOMPARE(result.ok, true);
    QCOMPARE(result.destination, QStringLiteral("/tmp/destination"));
    QCOMPARE(result.doneCount, 1);
    QCOMPARE(result.totalCount, 1);
}

void BackendClientTest::acceptsSynchronousTransportCompletion()
{
    SynchronousTransport transport;
    RustBackendClient client(&transport);

    QSignalSpy readySpy(&client, &IRustBackendClient::listReady);
    QSignalSpy failedSpy(&client, &IRustBackendClient::failed);

    ListRequest request;
    request.path = QStringLiteral("/tmp/example");
    request.sortField = QStringLiteral("name");
    request.sortAscending = true;
    request.foldersFirst = true;
    request.previews = true;

    const BackendRequestId requestId = client.list(request);

    QTRY_COMPARE(readySpy.count(), 1);
    QCOMPARE(failedSpy.count(), 0);
    QCOMPARE(readySpy.takeFirst().at(0).value<BackendRequestId>(), requestId);
}

void BackendClientTest::ignoresDuplicateTerminalEvents()
{
    InMemoryTransport transport;
    RustBackendClient client(&transport);

    QSignalSpy readySpy(&client, &IRustBackendClient::listReady);
    QSignalSpy failedSpy(&client, &IRustBackendClient::failed);

    ListRequest request;
    request.path = QStringLiteral("/tmp/example");
    request.sortField = QStringLiteral("name");
    request.sortAscending = true;
    request.foldersFirst = true;
    request.previews = true;

    const BackendRequestId requestId = client.list(request);
    transport.succeed(requestId, QByteArrayLiteral("[]"));
    transport.fail(requestId, QStringLiteral("backend_exit"), QStringLiteral("late failure"));
    transport.succeed(requestId, QByteArrayLiteral("[{\"fileName\":\"ignored\"}]"));

    QTRY_COMPARE(readySpy.count(), 1);
    QCOMPARE(failedSpy.count(), 0);
}

void BackendClientTest::forwardsTransportFailuresExactlyOnce()
{
    InMemoryTransport transport;
    RustBackendClient client(&transport);

    QSignalSpy failedSpy(&client, &IRustBackendClient::failed);

    SearchRequest request;
    request.rootPath = QStringLiteral("/tmp/example");
    request.query = QStringLiteral("needle");
    request.showHidden = false;
    request.sortField = QStringLiteral("name");
    request.sortAscending = true;
    request.foldersFirst = true;

    const BackendRequestId requestId = client.search(request);
    transport.fail(requestId, QStringLiteral("backend_exit"), QStringLiteral("exit code 7"));
    transport.fail(requestId, QStringLiteral("backend_exit"), QStringLiteral("duplicate"));

    QTRY_COMPARE(failedSpy.count(), 1);
    const BackendError error = failedSpy.takeFirst().constFirst().value<BackendError>();
    QCOMPARE(error.requestId, requestId);
    QCOMPARE(error.code, QStringLiteral("backend_exit"));
    QCOMPARE(error.message, QStringLiteral("exit code 7"));
}

void BackendClientTest::fakeBackendClientEmitsTypedSignalsWithoutProcessDependencies()
{
    FakeRustBackendClient client;
    QSignalSpy readySpy(&client, &IRustBackendClient::listReady);

    ListRequest request;
    request.path = QStringLiteral("/tmp/example");
    request.sortField = QStringLiteral("name");
    request.sortAscending = true;
    request.foldersFirst = true;
    request.previews = true;

    const BackendRequestId requestId = client.list(request);

    DirectoryEntry entry;
    entry.fileName = QStringLiteral("typed.txt");
    entry.filePath = QStringLiteral("/tmp/example/typed.txt");
    entry.fileUrl = QUrl(QStringLiteral("file:///tmp/example/typed.txt"));
    entry.fileKind = QStringLiteral("TXT");

    client.completeList(requestId, {entry});

    QTRY_COMPARE(readySpy.count(), 1);
    const QList<QVariant> signalArguments = readySpy.takeFirst();
    QCOMPARE(signalArguments.at(0).value<BackendRequestId>(), requestId);
    const QVector<DirectoryEntry> entries =
        signalArguments.at(1).value<QVector<DirectoryEntry>>();
    QCOMPARE(entries.size(), 1);
    QCOMPARE(entries.constFirst().fileName, QStringLiteral("typed.txt"));
}

void BackendClientTest::oneShotTransportMapsNonZeroExitToFailure()
{
    const QString python = QStandardPaths::findExecutable(QStringLiteral("python3"));
    QVERIFY2(!python.isEmpty(), "python3 must be available for transport tests");

    OneShotCliTransportOptions options;
    options.backendProgram = python;
    options.timeoutMs = 3000;
    options.maxStdoutBytes = 4096;
    options.maxStderrBytes = 4096;
    OneShotCliTransport transport(options);

    QSignalSpy completedSpy(&transport, &BackendTransport::completed);
    QSignalSpy failedSpy(&transport, &BackendTransport::failed);

    const BackendRequestId requestId = transport.start(
        {QStringLiteral("-c"),
         QStringLiteral("import sys; sys.stderr.write('boom\\n'); sys.exit(7)")});

    QTRY_COMPARE(failedSpy.count(), 1);
    QCOMPARE(completedSpy.count(), 0);

    const QList<QVariant> signalArguments = failedSpy.takeFirst();
    QCOMPARE(signalArguments.at(0).value<BackendRequestId>(), requestId);
    const BackendTransportError error =
        signalArguments.at(1).value<BackendTransportError>();
    QCOMPARE(error.requestId, requestId);
    QCOMPARE(error.code, QStringLiteral("backend_exit"));
    QVERIFY(error.message.contains(QStringLiteral("7")));
    QVERIFY(error.message.contains(QStringLiteral("boom")));
}

void BackendClientTest::oneShotTransportCancelsExactlyOnce()
{
    const QString python = QStandardPaths::findExecutable(QStringLiteral("python3"));
    QVERIFY2(!python.isEmpty(), "python3 must be available for transport tests");

    OneShotCliTransportOptions options;
    options.backendProgram = python;
    options.timeoutMs = 5000;
    options.maxStdoutBytes = 4096;
    options.maxStderrBytes = 4096;
    OneShotCliTransport transport(options);

    QSignalSpy completedSpy(&transport, &BackendTransport::completed);
    QSignalSpy failedSpy(&transport, &BackendTransport::failed);
    QSignalSpy releasedSpy(&transport, &OneShotCliTransport::requestReleased);

    const BackendRequestId requestId = transport.start(
        {QStringLiteral("-c"),
         QStringLiteral("import time; time.sleep(10)")});
    transport.cancel(requestId);

    QTRY_COMPARE(failedSpy.count(), 1);
    QTRY_COMPARE(releasedSpy.count(), 1);
    QCOMPARE(completedSpy.count(), 0);

    const BackendTransportError error =
        failedSpy.takeFirst().at(1).value<BackendTransportError>();
    QCOMPARE(error.requestId, requestId);
    QCOMPARE(error.code, QStringLiteral("cancelled"));
}

void BackendClientTest::oneShotTransportCancellationIsAsynchronous()
{
    const QString python = QStandardPaths::findExecutable(QStringLiteral("python3"));
    QVERIFY2(!python.isEmpty(), "python3 must be available for transport tests");

    OneShotCliTransportOptions options;
    options.backendProgram = python;
    options.timeoutMs = 5000;
    options.terminationGraceMs = 100;
    OneShotCliTransport transport(options);

    QSignalSpy completedSpy(&transport, &BackendTransport::completed);
    QSignalSpy failedSpy(&transport, &BackendTransport::failed);
    QSignalSpy terminateSpy(&transport, &OneShotCliTransport::processTerminateRequested);
    QSignalSpy killSpy(&transport, &OneShotCliTransport::processKillRequested);
    QSignalSpy releasedSpy(&transport, &OneShotCliTransport::requestReleased);

    const BackendRequestId requestId = transport.start(
        {QStringLiteral("-c"),
         QStringLiteral("import time; print('late', flush=True); time.sleep(10)")});
    transport.cancel(requestId);
    transport.cancel(requestId);

    QCOMPARE(failedSpy.count(), 1);
    QCOMPARE(completedSpy.count(), 0);
    QTRY_COMPARE(terminateSpy.count(), 1);
    QCOMPARE(killSpy.count(), 0);
    QTRY_COMPARE(releasedSpy.count(), 1);
    QCOMPARE(failedSpy.count(), 1);
    QCOMPARE(completedSpy.count(), 0);
}

void BackendClientTest::oneShotTransportKillsAfterTerminateGraceExpires()
{
    const QString python = QStandardPaths::findExecutable(QStringLiteral("python3"));
    QVERIFY2(!python.isEmpty(), "python3 must be available for transport tests");

    OneShotCliTransportOptions options;
    options.backendProgram = python;
    options.timeoutMs = 5000;
    options.terminationGraceMs = 25;
    OneShotCliTransport transport(options);
    QTemporaryDir readyDir;
    QVERIFY(readyDir.isValid());
    const QString readyPath = readyDir.filePath(QStringLiteral("ready"));

    QSignalSpy failedSpy(&transport, &BackendTransport::failed);
    QSignalSpy terminateSpy(&transport, &OneShotCliTransport::processTerminateRequested);
    QSignalSpy killSpy(&transport, &OneShotCliTransport::processKillRequested);
    QSignalSpy releasedSpy(&transport, &OneShotCliTransport::requestReleased);

    const BackendRequestId requestId = transport.start(
        {QStringLiteral("-c"),
         QStringLiteral(
             "import signal, sys, time; "
             "signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGTERM}); "
             "open(sys.argv[1], 'w').close(); time.sleep(10)"),
         readyPath});
    QTRY_VERIFY(QFileInfo::exists(readyPath));
    transport.cancel(requestId);

    QCOMPARE(failedSpy.count(), 1);
    QTRY_COMPARE(terminateSpy.count(), 1);
    QTRY_COMPARE(killSpy.count(), 1);
    QTRY_COMPARE(releasedSpy.count(), 1);
    QCOMPARE(failedSpy.count(), 1);
}

void BackendClientTest::oneShotTransportIgnoresLateFinishedAfterCancellation()
{
    const QString python = QStandardPaths::findExecutable(QStringLiteral("python3"));
    QVERIFY2(!python.isEmpty(), "python3 must be available for transport tests");

    OneShotCliTransportOptions options;
    options.backendProgram = python;
    options.timeoutMs = 5000;
    options.terminationGraceMs = 100;
    OneShotCliTransport transport(options);

    QSignalSpy completedSpy(&transport, &BackendTransport::completed);
    QSignalSpy failedSpy(&transport, &BackendTransport::failed);
    QSignalSpy releasedSpy(&transport, &OneShotCliTransport::requestReleased);

    const BackendRequestId requestId = transport.start(
        {QStringLiteral("-c"), QStringLiteral("import time; time.sleep(10)")});
    transport.cancel(requestId);

    QTRY_COMPARE(failedSpy.count(), 1);
    QTRY_COMPARE(releasedSpy.count(), 1);
    QCOMPARE(completedSpy.count(), 0);
    QCOMPARE(failedSpy.count(), 1);
}

void BackendClientTest::oneShotTransportDestructionReleasesActiveProcess()
{
    const QString python = QStandardPaths::findExecutable(QStringLiteral("python3"));
    QVERIFY2(!python.isEmpty(), "python3 must be available for transport tests");

    OneShotCliTransportOptions options;
    options.backendProgram = python;
    options.timeoutMs = 5000;
    options.terminationGraceMs = 25;
    auto *transport = new OneShotCliTransport(options);
    QPointer<OneShotCliTransport> guard(transport);

    transport->start({QStringLiteral("-c"), QStringLiteral("import time; time.sleep(10)")});
    transport->deleteLater();

    QTRY_VERIFY(guard.isNull());
}

void BackendClientTest::oneShotTransportTimesOutExactlyOnce()
{
    const QString python = QStandardPaths::findExecutable(QStringLiteral("python3"));
    QVERIFY2(!python.isEmpty(), "python3 must be available for transport tests");

    OneShotCliTransportOptions options;
    options.backendProgram = python;
    options.timeoutMs = 50;
    options.maxStdoutBytes = 4096;
    options.maxStderrBytes = 4096;
    OneShotCliTransport transport(options);

    QSignalSpy completedSpy(&transport, &BackendTransport::completed);
    QSignalSpy failedSpy(&transport, &BackendTransport::failed);

    const BackendRequestId requestId = transport.start(
        {QStringLiteral("-c"),
         QStringLiteral("import time; time.sleep(2)")});

    QTRY_COMPARE(failedSpy.count(), 1);
    QCOMPARE(completedSpy.count(), 0);

    const QList<QVariant> signalArguments = failedSpy.takeFirst();
    QCOMPARE(signalArguments.at(0).value<BackendRequestId>(), requestId);
    const BackendTransportError error =
        signalArguments.at(1).value<BackendTransportError>();
    QCOMPARE(error.requestId, requestId);
    QCOMPARE(error.code, QStringLiteral("timeout"));
}

void BackendClientTest::oneShotTransportCapsOutput()
{
    const QString python = QStandardPaths::findExecutable(QStringLiteral("python3"));
    QVERIFY2(!python.isEmpty(), "python3 must be available for transport tests");

    OneShotCliTransportOptions options;
    options.backendProgram = python;
    options.timeoutMs = 3000;
    options.maxStdoutBytes = 8;
    options.maxStderrBytes = 1024;
    OneShotCliTransport transport(options);

    QSignalSpy completedSpy(&transport, &BackendTransport::completed);
    QSignalSpy failedSpy(&transport, &BackendTransport::failed);

    const BackendRequestId requestId = transport.start(
        {QStringLiteral("-c"),
         QStringLiteral("print('0123456789abcdef')")});

    QTRY_COMPARE(failedSpy.count(), 1);
    QCOMPARE(completedSpy.count(), 0);

    const BackendTransportError error =
        failedSpy.takeFirst().at(1).value<BackendTransportError>();
    QCOMPARE(error.requestId, requestId);
    QCOMPARE(error.code, QStringLiteral("output_limit_exceeded"));
}

QTEST_MAIN(BackendClientTest)

#include "tst_backend_client.moc"
